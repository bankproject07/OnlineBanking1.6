package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.obs.bean.Admin;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class AdminDaoImpl implements IAdminDao {

	PreparedStatement pst;
	Connection con;
	Statement st;
	@Override
	public Admin getAdmin(String id) throws UserException {
		Admin admin=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Admin";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			admin=new Admin();
			admin.setAdminid(rs.getString(1));
			admin.setAdminPassword(rs.getString(2));
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return admin;
	}

}
