package com.cg.obs.util;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;



public class DBUtil 
{
	public static Connection getConnection() throws SQLException {

		System.out.println("In DBUtils");
		/*  OracleDataSource ods= new OracleDataSource();
		  ods.setUser("system");
		  ods.setPassword("mysql07");
		  ods.setDriverType("thin");
		  ods.setNetworkProtocol("tcp");
		  ods.setURL("jdbc:oracle:thin:@192.168.0.115:1521:XE");
		 */
		InitialContext ic;
		DataSource ds;
		Connection con = null;
		try {
			System.out.println("in try");
			ic = new InitialContext();
			System.out.println(ic);
			System.out.println( ic.lookup("java:/jdbc/OracleDS"));
			ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
			System.out.println(ds);
			con = ds.getConnection();
			System.out.println(con);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println("Exception occured:"+e.getMessage());
		}
		return con;
	}
}
