package com.cg.obs.test;

import com.cg.obs.bean.Users;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;

public class ManualTesting {

	public static void main(String[] args) {
		
		IUserService service=new UserServiceImpl();
		Users user=service.getUser(1001);
		System.out.println(user);
		
		
	}

}
